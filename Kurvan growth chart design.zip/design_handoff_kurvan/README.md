# Handoff: Kurvan — growth tracking for Swedish newborns (0–24 months)

## Overview

Kurvan lets a parent record their child's **vikt** (weight), **längd** (length) and
**huvudomfång** (head circumference) and see those values plotted on the same
standard-deviation reference curves that Swedish BVC (barnavårdscentralen) uses.
The product exists to close the gap between BVC visits, when a parent has a number
written on a card and no way to interpret it.

**All user-facing copy is Swedish.** This README is English; nothing in the product is.

The single hardest requirement: the app must aid *understanding* without becoming a
source of anxiety. Everything in "Product rules that must survive implementation"
below is load-bearing for that. Read it before writing UI.

Scope: children 0–24 months, born at term (37–42 weeks), one account, multiple
children. Out of scope but not foreclosed: multiple users per child, read-only
sharing, GDPR export/delete.

## About the design files

The files in this bundle are **design references written in HTML** — running
prototypes that show intended look and behaviour. They are **not production code to
copy**. The task is to recreate these designs in the target codebase's own
environment (React, React Native, Vue, SwiftUI, native Android…), using its existing
patterns, component library and state management. If no environment exists yet,
pick the appropriate framework and implement there.

The brief specifies **shadcn/ui** as the component vocabulary. In a React/Tailwind
codebase, map to shadcn primitives directly: `Card`, `Button`, `Input`, `Label`,
`Tabs`, `ToggleGroup`, `Sheet` (mobile child switcher), `Table` (desktop history),
`Alert` (the BVC attention card). The visual tokens below override shadcn's default
palette — the neutral scale is warm, not slate.

The chart is hand-drawn SVG in the prototype. Do not swap it for an off-the-shelf
charting library without checking it can do all of: a non-linear (piecewise) x-scale,
a log y-scale, seven reference curves with per-curve dash patterns, filled bands
between curves, and hit targets larger than the plotted dots. Most cannot. Writing
~150 lines of SVG against `d3-scale` is the expected path.

## Fidelity

**High fidelity.** Colors, typography, spacing, copy and interaction behaviour are
final and should be recreated faithfully. Exact values are listed under Design
tokens and per-screen below. The one deliberately unfinished area is the reference
curve dataset — see "Reference data" below.

---

## Product rules that must survive implementation

These are not styling preferences. If an implementation detail conflicts with one of
these, the rule wins.

1. **Never a verdict.** No status word, badge, colour-coded state, score, smiley or
   traffic light anywhere. There is no green "normal", so there is no red to fall out
   of. The home screen leads with a *written reading* in plain Swedish.
2. **Never diagnose or imply a diagnosis.** Never instruct the parent on what to do
   medically. Route to BVC.
3. **The word "percentil" must never appear.** Swedish charts use SD. Standard terms:
   tillväxtkurva, BVC, vikt, längd, huvudomfång, SD.
4. **Trend over position.** Copy describes whether the child follows its own channel
   over the BVC windows: 3 months under age 1, 6 months for ages 1–2. Where the
   history is too short, the app says so outright rather than filling the gap.
5. **Channel-crossing in early infancy is normal** and is named as expected in copy.
   The app must not flag it.
6. **One measurement is its own state.** One point renders as one point — no
   connecting line, no trend sentence. Heading: "En punkt är ingen kurva."
   Under 14 days the copy also explains the normal ~6 % weight loss.
7. **Weight is never read alone.** If there are ≥3 weight points and ≤1 length point,
   the reading says weight without length can't be interpreted and suggests asking
   BVC to measure. It does not produce a confident weight-only assessment.
8. **No combined "tillväxtkurva".** Each measure has its own curve and its own chart:
   Viktkurva, Längdkurva, Huvudomfångskurva. Values are never plotted on a composite
   or derived measure. The word "tillväxtkurva" may appear in prose about the concept;
   it is never the name of a chart or a screen.
9. **Escalation is single and calibrated.** One quiet card appears only on the real
   BVC triggers (below). It never diagnoses.
10. **Contacting BVC is never gated on a flag** and never a fake integration. There
    are no "Ring BVC" / "Skriv till BVC" action buttons — most mottagningar have no
    chat and the phone number is region-specific. Instead a persistent plain-copy
    card says contacting BVC is fine and normal, and points to the BVC card and
    1177.se. (If the shipping app later has a verified per-region number for the
    user's mottagning, a `tel:` link becomes legitimate; until then, copy only.)
11. **Never encode meaning in colour alone.** The chart works in greyscale and for
    colour-blind users: SD lines are distinguished by band shading *and* stroke width
    *and* dash pattern *and* an edge label (−3 −2 −1 M +1 +2 +3).
12. **Wrong-child entry is a real, damaging error.** The active child is visible in
    the header on every screen, is restated on the measurement form, and switching
    is one tap.

---

## Domain model

```
Child {
  id: string
  name: string
  sex: 'flicka' | 'pojke'          // determines which reference table is used
  birth: ISO date 'YYYY-MM-DD'
  gw: int                          // gestational weeks at birth, 37–42 term
  gd: int                          // gestational days, 0–6
  measurements: Measurement[]
}

Measurement {
  id: string
  date: ISO date                   // date of measurement, not of entry
  vikt:  number | null             // kg, 3 decimals (gram precision)
  langd: number | null             // cm, 1 decimal (mm precision)
  huvud: number | null             // cm, 1 decimal (mm precision)
}
```

At least one of `vikt`/`langd`/`huvud` must be non-null; all three null is invalid.
Any single one alone is valid — BVC sometimes monitors weight more often than length.

### Age correction for gestational age

```
corrDays(child) = 280 - (child.gw * 7 + child.gd)
ageMonths(child, date) = max(0, (daysBetween(child.birth, date) - corrDays(child)) / 30.4375)
```

A child born 38+0 gets `corrDays = 14`, so its whole curve shifts 14 days left relative
to uncorrected age. Term range 37–42 gives corrections of +21 to −14 days. This is why
gestational age is a **required** field, not a nicety, and why the add-child form has a
live readout of the resulting correction.

### Reference data and SDS

Reference values are `M` (mean) and `S` (one SD) per measure, per sex, at knot ages
`[0, 0.5, 1, 2, 3, 4, 5, 6, 9, 12, 15, 18, 21, 24]` months, interpolated with a
**monotone cubic Hermite (Fritsch–Carlson)** spline so the curves are smooth and never
overshoot. See `KurvanApp.dc.html` → `REF`, `mono()`, `refAt()`, `sds()`.

```
sds(sex, measure, ageMonths, value) = (value - M(ageMonths)) / S(ageMonths)
```

> **⚠ The `REF` table in the prototype is realistic but reconstructed, not authoritative.**
> Replace it with the extracted official dataset before anything ships. The interpolation
> and rendering code is dataset-agnostic — swap the numbers, keep the shape. The two
> official PC PAL charts this was built against are in `referens/`.

### Escalation thresholds (the only triggers for the attention card)

- Weight SDS drift of **more than 1.0 SDS** across the relevant window — 3 months for
  a child under 1 year, 6 months for 1–2 years. Implemented by walking back through
  the weight points to the most recent one at least ~0.85 × window ago and comparing SDS.
- **Length below −2 SD** at the latest measurement.

Both are rates/positions the Swedish BVC actually escalates on. Nothing else triggers
anything. If no point far enough back exists, there is no drift value and the reading
says so instead of guessing.

---

## The chart

One chart component, three instances (vikt / längd / huvud), three sizes
(mini ~260×150, mobile 344×300, desktop 700×400).

### X axis — piecewise compressed age

The official paper chart gives roughly a third of its width to the first three months.
That's clinically right and must be preserved. The scale is piecewise-linear in three
segments, each occupying a fixed fraction of the plot width:

| Age range   | Fraction of width |
|-------------|-------------------|
| 0–3 months  | 0.34              |
| 3–12 months | 0.38              |
| 12–24 months| 0.28              |

Implemented as `ux(m)` → normalised position, then rescaled to the visible domain.
Three zoom ranges, exposed as pills: **0–3 mån**, **0–12 mån**, **0–2 år**. Zoom
re-normalises within the same piecewise function, so the compression is consistent
at every zoom level. This is how a 24-month chart stays readable at 390 px.

Tick labels: `F` at age 0 (födsel), then month numbers. Tick density thins on narrow
canvases — at <460 px the 0–12 view labels even months only, the 0–24 view labels
0, 2, 4, 6, 9, 12, 15, 18, 21, 24. Mini charts label only every 3rd (0–12) or 6th
(0–24) month. A caption under the chart states "Vågrätt: ålder i månader, F = födsel"
rather than an in-plot axis title.

### Y axis

- **Weight is logarithmic** (`log(v)` mapped linearly). The SD bands are visually
  uneven as a result. This is correct. Do not linearise it.
- Length and head circumference are linear.
- Domain is the union of the ±3 SD envelope over the visible age range and the child's
  own points, padded 4 %.
- Gridline ticks: weight `[2,3,4,5,6,7,8,9,10,12,14,16,18,20]` kg,
  length `[40,45,…,95]` cm, head `[32,34,…,50]` cm — drawn only when inside the domain,
  and suppressed within 13 px of the plot top so they don't collide with the unit label.

### Reference curves — seven, differentiated without colour

| Curve | Stroke        | Width | Dash  | Edge label |
|-------|---------------|-------|-------|------------|
| M     | `#7E7568`     | 1.7   | solid | `M`        |
| ±1 SD | `#A79E92`     | 1.2   | `4,3` | `+1` / `−1`|
| ±2 SD | `#A79E92`     | 1.0   | solid | `+2` / `−2`|
| ±3 SD | `#A79E92`     | 1.0   | `1,3` | `+3` / `−3`|

Filled bands behind them, lightest outward: ±3 `#F4F1EB`, ±2 `#EBE6DC`, ±1 `#DFD8CB`.
Gridlines are white at 0.7–0.85 opacity, drawn over the bands and under the curves.
Curves are sampled at 91 points across the visible domain.

### The child's own trajectory

- Polyline `#1C1A17`, width 2.4 (mobile/desktop) or 1.8 (mini), round joins and caps.
- **Drawn only when there are ≥2 points.** One point is a dot, never a line.
- Dots: r 4.2 filled `#1C1A17`; selected dot inverts to white fill with a 3 px
  `#1C1A17` ring at r 6. Mini charts: r 2.4, non-interactive.
- Hit target: an invisible `r=16` circle over each dot. Not the dot itself — the dot
  is far below a 44 px touch target.
- Tapping a dot opens a detail card (below the chart on mobile, in the right column on
  desktop) with value + unit, date, corrected age, and the SD phrase. Dismiss with ×.
- Selection is cleared whenever the measure or the child changes.

### SD phrasing (used in the detail card, the latest-values rows and the reading)

```
|sd| ≤ 1   →  "0,4 SD över medel — inom det vanligaste området"
|sd| ≤ 2   →  "1,3 SD under medel — mellan 1 och 2 SD"
otherwise  →  "2,4 SD under medel — utanför 2 SD"
```

Always a description, never an evaluation. Swedish decimal comma throughout.

---

## Screens

Header (all screens except first-run and add-child): active child chip on the left —
32 px circular avatar with the initial on `#1C5C66`, name, corrected age, "byt ▾" —
opening the child switcher; "Mätningar" text button on the right. 14/16 px padding,
1 px `#E6E1DA` bottom border.

Mobile primary action is a full-width bottom button, "Lägg till mätning", 56 px,
`#1C5C66`, 14 px radius, over a `#FAF8F5` → transparent gradient fade. Present on
home, chart and history.

### 1. Första start (no child)

Purpose: establish trust and purpose in a few seconds.

Layout: 36/24 px padding, column, 28 px gaps. Mark (44 px `#1C5C66` rounded square,
serif "K"), wordmark "Kurvan" at 34 px Source Serif 4 600, one-sentence promise at
17 px. Then a white card with three numbered points (22 px outlined circles):
same reference curves as BVC; you see the child follow its own channel over time,
which is what matters; **the app assesses nothing and diagnoses nothing — BVC does
that, and we help you get there.** Bottom: "Lägg till barn" (54 px, `#1C5C66`),
and a quiet line that data is stored on this device only.

Desktop: same content, single 560 px column, 40 px heading, left-aligned button.

### 2. Lägg till barn

Fields: Namn (text) · Kön (two 52 px segmented buttons, Flicka / Pojke — selected is
filled `#1C5C66`) · Födelsedatum (date).

**Graviditetslängd vid födseln** is its own white card: two equal-width numeric inputs,
`veckor` + `dagar`, separated by a "+" glyph. Both inputs must be
`flex: 1 1 0; min-width: 0; width: 100%` — a naive `flex: 1` on the label with an
unconstrained input overflows the card. Beneath, the plain-Swedish explanation:
it's on the BVC card, usually as "39+2"; a child born in week 38 has grown two weeks
less than one born in week 40; we shift the curve by the same amount so the comparison
is fair; term is 37–42 weeks. Below a dashed divider, a live readout:
"Ålderskorrektion: **14 dagar, kurvan flyttas åt vänster**" (or "ingen — född vecka 40+0",
or a placeholder until weeks are entered).

Optional card: Födelsevikt / Födelselängd / Huvudomfång, three inputs in a row, saved
as a measurement dated the birth date if any is filled.

Desktop: two-column grid for the first four fields, explanation as a full-width card,
three birth inputs in a 3-column grid.

### 3. Hem / översikt

Card 1 — **the reading**. Serif heading + one paragraph of plain Swedish at 16 px /
1.55. Headings and bodies vary by state (see State machine below). Then, under a
divider, the latest measurement: a date/age line, then **three full-width rows**, one
per measure — label left, value right at 21 px 600 tabular-nums, SD phrase on its own
line beneath at 13 px `#6E675E`, hairline `#F2EEE7` between rows. (A three-column grid
was tried and is too cramped at 390 px.)

Card 2 — **attention**, conditional. White card, 1 px `#C9C1B4` border, square outlined
"!" glyph, heading "Något att ta upp på BVC", one paragraph. No colour, no icon fill,
no alarm. Copy always: what moved, that it happens for many reasons and may mean
nothing, that this is exactly what BVC looks at with you, and to bring it to the next
visit or call before if you want.

Card 3 — **Kurvor**. Heading + one line: each of the three has its own curve; they're
read together but each measure is plotted on its own. Then three stacked buttons —
Viktkurva, Längdkurva, Huvudomfångskurva — each with a mini chart preview and "Öppna →".
Desktop shows the same three as a 3-column grid of cards.

Card 4 — **Fråga BVC när du vill**. `#E9F1F1` on `#CFE0E1`, no buttons. Copy: you don't
need a good reason to get in touch; questions about weight, length, breastfeeding and
eating are exactly what BVC is for, including between booked visits; it's entirely fine
to call just because you're wondering. Second line: the number for your mottagning is
on the BVC card and at 1177.se. This card is permanent — never conditional on a flag.

Desktop home: name + age header with "Lägg till mätning"; reading and BVC/attention in
a 1.35fr / 1fr grid; the three curve cards in a row below.

### 4. Kurvor (chart screen)

Mobile: back link to the child, a 3-way segmented control (Vikt / Längd / Huvudomfång),
a zoom pill row (0–3 mån / 0–12 mån / 0–2 år), the chart in a white card with the axis
caption and legend below, the selected-point card when a dot is tapped, then the
footnote.

Footnote, always visible: the curves show mean (M) and standard deviations for Swedish
term-born children; roughly 68 % of all children fall within ±1 SD and 95 % within
±2 SD; the age is corrected N days for gestational length W+D.

Desktop: title is the measure's own name ("Viktkurva"), zoom pills top right, a
1.6fr / 1fr grid — big chart with the measure tabs above it on the left; on the right
the selected-point card, then "De andra kurvorna" with the other two as clickable mini
charts (clicking promotes one to the big slot), then the footnote. Weight and length
are always visible together, which is the point.

### 5. Ny mätning

Reachable in one action from home. One-handed: everything within thumb reach, 56 px
inputs, `inputmode="decimal"`.

Active child restated at the top with an avatar and a "Byt" link. Then date (defaults
to today, editable — "Står som i dag. Ändra om du fyller i från BVC-kortet i efterhand.").
Then three labelled inputs with unit suffixes inside the field: Vikt / kg, Längd / cm,
Huvudomfång / cm. Helper: "Fyll i det du har — ett värde räcker. Använd decimalkomma,
som på kortet."

Validation: all three empty → "Fyll i minst ett värde." Nothing else blocks. Parse
accepts comma or dot; display always uses comma. Weight 3 decimals, length and head 1.

Desktop: 4-column grid (date + three values), inline save/cancel.

### 6. Mätningar (history)

Mobile: one card per measurement, newest first — date, corrected age, the three values
(`—` where absent), and Ändra / Ta bort actions above a hairline. Empty state is a
dashed card: it's empty for now; if you have the BVC card to hand you can fill in older
measurements too — the curve gets more readable the more points it has; plus the add
button.

Desktop: a table, `1.3fr 1fr 1fr 1fr 1fr 0.9fr` — Datum, Ålder, Vikt, Längd,
Huvudomfång, actions. Header row `#F5F2EC`, rows separated by `#EFEBE4`, tabular-nums.

"Ändra" opens the measurement form pre-filled and replaces the record on save (same id).
"Ta bort" removes it. Both must be trivially reachable — correcting a typo is a common,
low-stakes task and should feel like one.

### 7. Byte av barn

Mobile: bottom sheet — grab handle, the line "Mätningar sparas på det barn du väljer
här.", one 60 px row per child (avatar, name, "Flicka · 11 mån 2 v · född 10 augusti
2025", "Vald" marker on the active one, `#E9F1F1` fill + `#1C5C66` border when active),
then a dashed "+ Lägg till barn". Tap anywhere above the sheet to dismiss.

Desktop: the same rows live permanently in the 268 px left sidebar, above the
Översikt / Kurvor / Mätningar nav which is pinned to the bottom with `margin-top: auto`.
The sidebar must fill the full viewport height on every screen.

---

## State machine for the home reading

Evaluated in this order; the first match wins.

| Condition | Heading | Body |
|---|---|---|
| 0 measurements | Kurvan är tom än | Enter what's on the BVC card and the curve starts to take shape; older measurements can be backfilled. |
| exactly 1 | En punkt är ingen kurva | We can show where the values sit relative to other children, but not how the child is growing — that only appears once there are points to draw a line between. A first point sitting high or low says very little in itself. **If age < 14 days**, append the normal ~6 % weight loss and return to birth weight by two weeks. |
| ≥3 weight points and ≤1 length point | Bara vikt sedan födseln | N weight measurements but only one length. Weight without length is hard to interpret — a child growing well in length should weigh more. The curve shows the weight as it is and draws no conclusions from it. Suggests asking BVC to measure length at the next visit. |
| ≥2 points, no comparison point far enough back | Så ser kurvan ut nu | Position of weight (and length) in SD, then: there aren't yet measurements spanning enough time to say anything about direction; many children change channel during the first six months while finding their own size — that's expected. |
| drift < 0.7 SDS | Så ser kurvan ut nu | …has stayed in roughly the same channel over the last N months. That's usually the interesting thing — not where the curve sits, but that it follows itself. |
| 0.7 ≤ drift < 1.0 | Så ser kurvan ut nu | The curve has moved X,X SD up/down over the last N months. Changing channel is common in the first year and need not mean anything. |
| drift ≥ 1.0 | Så ser kurvan ut nu | The curve has moved X,X SD up/down over the last N months. **+ attention card.** |

The attention card also fires independently when latest length SDS < −2.

Copy is generated from these templates with the child's name and formatted numbers
interpolated. Keep the templates as data, not as string concatenation scattered through
components — this text is the highest-risk surface in the product and should be
reviewable in one place. **Have a BVC nurse read it before shipping.**

---

## Design tokens

### Colour — warm neutrals, one teal accent

| Token | Hex | Use |
|---|---|---|
| bg | `#FAF8F5` | app background |
| bg-canvas | `#F0EDE6` | the design canvas only, not the app |
| surface | `#FFFFFF` | cards, inputs |
| surface-sunken | `#F5F2EC` | desktop sidebar, table header |
| surface-muted | `#F1EDE6` | segmented control track |
| border | `#E6E1DA` | card and header borders |
| border-strong | `#C9C1B4` | attention card, dashed empty states |
| border-input | `#D8D2C8` | input borders |
| hairline | `#EFEBE4` / `#F2EEE7` | in-card dividers |
| text | `#1C1A17` | primary text, own-trajectory line |
| text-secondary | `#3D3830` | body copy |
| text-muted | `#6E675E` | labels, captions, axis text |
| accent | `#1C5C66` | primary buttons, links, active states |
| accent-hover | `#164A52` | |
| accent-ink | `#123F46` | link hover |
| accent-surface | `#E9F1F1` | BVC card, active nav |
| accent-border | `#CFE0E1` | BVC card border |
| accent-text | `#1C3A3E` / `#2B4E52` | text on accent surface |
| chart-band-3 | `#F4F1EB` | ±3 SD fill |
| chart-band-2 | `#EBE6DC` | ±2 SD fill |
| chart-band-1 | `#DFD8CB` | ±1 SD fill |
| chart-mean | `#7E7568` | M curve |
| chart-sd | `#A79E92` | ±1/2/3 curves |
| error | `#8A2B12` | form validation text |

No colour carries meaning on its own anywhere in the product.

### Typography

- Display / headings: **Source Serif 4**, weight 600. 52 / 40 / 34 / 30 / 28 / 26 /
  24 / 21 / 20 px. Letter-spacing −0.01 to −0.02em at the largest sizes.
- UI and body: **Public Sans**, 400 / 500 / 600 / 700. Body 15–17 px at 1.45–1.6
  line-height; labels 13–15 px; captions and axis text 12–13 px (SVG 8–10 px).
- All numeric values use `font-variant-numeric: tabular-nums`.
- Swedish decimal comma everywhere, in inputs and in output.
- Prose uses `text-wrap: pretty`.

### Spacing, radius, elevation

- Spacing: 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 48, 56, 64.
- Radius: 6 (small marks), 9–10 (buttons, inputs), 12 (list rows, inner cards),
  14 (cards, primary mobile button), 20 (bottom sheet top), 28 (phone frame), 999 (pills, avatars).
- Shadows are minimal: `0 1px 3px rgba(28,26,23,0.12)` on the active segmented tab,
  `0 6px 20px rgba(28,92,102,0.22)` on the mobile primary button. Cards use borders,
  not shadows.

### Touch targets

Nothing interactive below 44 px. Primary buttons 54–56 px. Form inputs 52–56 px on
mobile, 48 px on desktop. Chart dots get 32 px invisible hit circles.

---

## Responsive

Two layouts, not a fluid continuum. Mobile (design width 390 px) is primary for entry;
desktop (design width ≥1024 px, content max ~1000–1280 px) is primary for chart study.
The prototype selects between them with a `mode` prop for presentation purposes — in
production this is a breakpoint at roughly 1024 px.

Mobile: single column, bottom-anchored primary action, bottom-sheet child switcher,
one chart at a time via tabs.

Desktop: 268 px persistent sidebar (children on top, nav pinned to the bottom, full
viewport height), content column with the big chart plus the other two measures beside
it, tabular history.

---

## Assets

None. No images, no icon library, no illustrations. The only graphics are the SVG
charts, generated from data. The "K" mark is a serif letterform in a rounded square.

Fonts: Source Serif 4 and Public Sans, both Google Fonts (SIL Open Font License).
Self-host in production.

`referens/` contains the two official PC PAL 0–2 year charts (flicka, pojke) the design
was built against. They are the source of the conventions — SD lines, compressed age
axis, log weight axis — and the reference dataset should be extracted from them (or
from the official source they come from) to replace the placeholder table.

---

## Files in this bundle

| File | What it is |
|---|---|
| `KurvanApp.dc.html` | The application itself — all screens, mobile and desktop, chart engine, reference data, reading logic. This is the primary reference. |
| `Kurvan.dc.html` | The presentation canvas: 21 live frames of the app in every screen and state, plus the design rationale. Reference for which states exist and what each should look like. |
| `support.js` | Runtime for the prototype format. Not part of the design; not needed in production. |
| `referens/PCPAL-0-2ar-flicka.pdf` | Official Swedish growth chart, girls 0–2 years. |
| `referens/PCPAL-0-2ar-pojke.pdf` | Official Swedish growth chart, boys 0–2 years. |

Open either `.dc.html` directly in a browser. In `KurvanApp.dc.html`, the interesting
parts of the logic class are: `REF` (reference data), `mono`/`refAt`/`sds` (interpolation
and SDS), `ux`/`makeX` (the compressed age scale), `chart()` (the whole SVG renderer),
`sdPhrase()` (SD wording), and `reading()` (the home-screen state machine).

## Known gaps for the implementer

1. **Reference dataset is placeholder.** Realistic, but reconstructed. Replace before shipping.
2. **Escalation copy needs clinical review.** A BVC nurse should read `reading()` and the
   attention texts before release.
3. **Persistence** is in-memory in the prototype. The first-run screen promises
   device-local storage; honour that, or change the promise.
4. **No auth, no sync, no export.** Out of scope, but the data model is deliberately
   flat and serialisable so GDPR export/delete and read-only sharing can be added.
5. **Preterm children (<37 weeks)** are out of scope. The age-correction maths already
   handles them, but the reference curves and the clinical reading do not — the app should
   say so rather than silently plotting them on term curves.
